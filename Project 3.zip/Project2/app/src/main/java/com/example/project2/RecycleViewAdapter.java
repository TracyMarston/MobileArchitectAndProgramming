package com.example.project2;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class RecycleViewAdapter extends RecyclerView.Adapter<RecycleViewAdapter.MyViewHolder> {
    List<productModel> productList;
    Context context;


    public RecycleViewAdapter(List<productModel> productList, Context context) {
        this.productList = productList;
        this.context = context;

    }


    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.one_product, parent, false);
        MyViewHolder holder = new MyViewHolder(view);
        return holder;
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {
        holder.outputID.setText(String.valueOf(productList.get(position).getID()));
        holder.outputName.setText(productList.get(position).getProduct());
        holder.outputCategory.setText(productList.get(position).getCategory());
       // holder.outputDescription.setText(productList.get(position).getDescription());
        holder.outputQty.setText(String.valueOf(productList.get(position).getQuantity()));

        holder.parentLayout.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view){
                Intent intent = new Intent(context, CreateItem.class);
                intent.putExtra("id", productList.get(position).getID());
                context.startActivity(intent);
            }
        });

    }

    @Override
    public int getItemCount() {
        return productList.size();
    }


    public class MyViewHolder extends RecyclerView.ViewHolder {
        TextView outputID;
        TextView outputName;
        TextView outputCategory;
        //TextView outputDescription;
        TextView outputQty;
        ConstraintLayout parentLayout;



        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            outputID = itemView.findViewById(R.id.outputID);
            outputName = itemView.findViewById(R.id.outputName);
            outputCategory = itemView.findViewById(R.id.outputCategory);
            outputQty = itemView.findViewById(R.id.outputQty);

            parentLayout = itemView.findViewById(R.id.oneProductLayout);

        }


    }
}
