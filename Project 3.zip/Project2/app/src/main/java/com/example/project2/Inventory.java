package com.example.project2;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import androidx.gridlayout.widget.GridLayout;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.GridView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;


public class Inventory extends AppCompatActivity{
    Button btnCreate, btnLoad;
    private RecyclerView recyclerView;
    private RecyclerView.Adapter mAdapter;
    private RecyclerView.LayoutManager layoutManager;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inventory);


        btnCreate = findViewById(R.id.btnCreate);
        btnLoad = findViewById(R.id.btnLoad);





        btnCreate.setOnClickListener(v ->{
            Intent intent = new Intent(this, CreateItem.class);
            startActivity(intent);

        });



        btnLoad.setOnClickListener(v -> {

            DBInventory Inventory = new DBInventory(Inventory.this);
            List<productModel> allProducts;
            allProducts = Inventory.ReadAll();

            recyclerView = (RecyclerView) findViewById(R.id.productList);
            recyclerView.setHasFixedSize(true);
            layoutManager = new LinearLayoutManager(this);
            recyclerView.setLayoutManager(layoutManager);
            mAdapter = new RecycleViewAdapter(allProducts, this);
            recyclerView.setAdapter(mAdapter);



        });



    }


}