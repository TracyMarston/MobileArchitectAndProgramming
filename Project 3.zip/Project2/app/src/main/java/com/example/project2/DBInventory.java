package com.example.project2;

import android.content.ContentValues;
import android.content.Context;


import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.widget.EditText;

import java.util.ArrayList;
import java.util.List;

public class DBInventory extends SQLiteOpenHelper {

    public static final String COLUMN_PRODUCT = "PRODUCT";
    public static final String COLUMN_CATEGORY = "CATEGORY";
    public static final String COLUMN_DESCRIPTION = "DESCRIPTION";
    public static final String COLUMN_QUANTITY = "QUANTITY";
    public static final String COLUMN_ID = "ID";

    public DBInventory(Context cv) {super(cv, "inventory.db", null, 1); }
    public static final String PRODUCT_TABLE = "PRODUCT_TABLE";




    @Override
    public void onCreate(SQLiteDatabase inventoryDB) {
        String createTableStatement = "CREATE TABLE " + PRODUCT_TABLE + " (" + COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " + COLUMN_PRODUCT + " TEXT, " + COLUMN_CATEGORY + " TEXT, " + COLUMN_DESCRIPTION + " TEXT, " + COLUMN_QUANTITY + " INTEGER)";
        inventoryDB.execSQL(createTableStatement);

    }


    @Override
    public void onUpgrade(SQLiteDatabase inventoryDB, int oldVersion, int newVersion) {
        inventoryDB.execSQL("drop Table if exists PRODUCT_TABLE");  // Don't create a new table if it already exists.
    }

    public boolean insertOne(productModel productModel){
        //Create an instance of the Database
        SQLiteDatabase inventoryDB = this.getWritableDatabase();
        ContentValues content = new ContentValues();

        /* Assign Values to input based on columns and input values from form */
        content.put(COLUMN_PRODUCT, productModel.getProduct());
        content.put(COLUMN_CATEGORY, productModel.getCategory());
        content.put(COLUMN_DESCRIPTION, productModel.getDescription());
        content.put(COLUMN_QUANTITY, productModel.getQuantity());


        // Insert content Values into Product Table.
        long insert = inventoryDB.insert(PRODUCT_TABLE, null, content);
        return insert != -1;
        }

        public boolean updateInventory(productModel productModel, EditText findID){
            SQLiteDatabase inventoryDB = this.getWritableDatabase();
            ContentValues content = new ContentValues();

            content.put(COLUMN_PRODUCT, productModel.getProduct());
            content.put(COLUMN_CATEGORY, productModel.getCategory());
            content.put(COLUMN_DESCRIPTION, productModel.getDescription());
            content.put(COLUMN_QUANTITY, productModel.getQuantity());



           long updated = inventoryDB.update(PRODUCT_TABLE, content, COLUMN_ID + " = ?", new String[] {findID});
            return  updated != -1;

        }
    public boolean updateInventory(productModel productModel, String findID){
        SQLiteDatabase inventoryDB = this.getWritableDatabase();
        ContentValues content = new ContentValues();

        content.put(COLUMN_PRODUCT, productModel.getProduct());
        content.put(COLUMN_CATEGORY, productModel.getCategory());
        content.put(COLUMN_DESCRIPTION, productModel.getDescription());
        content.put(COLUMN_QUANTITY, productModel.getQuantity());



        inventoryDB.update(PRODUCT_TABLE, content, COLUMN_ID + " = ?", new String[] {findID});
        return  true;

    }


        public List<productModel> ReadAll(){
            List<productModel> returnList = new ArrayList<>();

            String queryString = "SELECT * FROM " + PRODUCT_TABLE;

            SQLiteDatabase inventoryDB = this.getReadableDatabase();
            Cursor cursor = inventoryDB.rawQuery(queryString, null);
            if(cursor.moveToFirst()){
              do{
                  int productID = cursor.getInt(0);
                  String productName = cursor.getString(1);
                  String productCategory = cursor.getString(2);
                  String productDescription = cursor.getString(3);
                  int productQty = cursor.getInt(4);

                  productModel newProduct = new productModel(productID, productName, productCategory, productDescription, productQty);
                  returnList.add(newProduct);
              } while (cursor.moveToNext());
                //Close DB and Cursor

            }
            cursor.close();
            inventoryDB.close();
            return returnList;
        }


    }










