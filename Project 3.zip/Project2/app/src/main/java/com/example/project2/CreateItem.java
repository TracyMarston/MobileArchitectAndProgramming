package com.example.project2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;

import android.view.View;
import android.widget.EditText;

import android.widget.Button;

import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;


public class CreateItem extends AppCompatActivity {

    EditText product, desc, category, qty, idItem;
    Button btnSave, btnUpdate;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_item);


        idItem = findViewById(R.id.inputID);
        product = findViewById(R.id.inputProduct);
        desc = findViewById(R.id.inputDesc);
        category = findViewById(R.id.inputCategory);
        qty = findViewById(R.id.inputQty);
        btnSave = findViewById(R.id.btnSave);
        btnUpdate = findViewById(R.id.btnUpdate);







        // Call Update Function
        btnUpdate.setOnClickListener(v -> {
            productModel updateProduct;
            try {



                updateProduct = new productModel(1,
                        product.getText().toString(),
                        category.getText().toString(),
                        desc.getText().toString(),
                        Integer.parseInt(qty.getText().toString()));
                Toast.makeText(CreateItem.this, updateProduct.toString(), Toast.LENGTH_SHORT).show();
            }
            catch (Exception e) {

                Toast.makeText(CreateItem.this, "Error Updating Product", Toast.LENGTH_SHORT).show();
                updateProduct = new productModel(-1,
                        "Error Name",
                        "No Category",
                        "No Desc",
                        0);

            }
            DBInventory Inventory = new DBInventory(CreateItem.this);
            boolean isUpdate = Inventory.updateInventory(updateProduct, idItem);
            Toast.makeText(CreateItem.this, "Success=" + isUpdate, Toast.LENGTH_SHORT).show();

        });


            btnSave.setOnClickListener(v -> {
                productModel ProductItem;

                try {
                    ProductItem = new productModel(1,
                            product.getText().toString(),
                            category.getText().toString(),
                            desc.getText().toString(),
                            Integer.parseInt(qty.getText().toString()));

                    Toast.makeText(CreateItem.this, ProductItem.toString(), Toast.LENGTH_SHORT).show();
                } catch (Exception e) {
                    Toast.makeText(CreateItem.this, "Error Creating Product", Toast.LENGTH_SHORT).show();
                    ProductItem = new productModel(-1,
                            "Error Name",
                            "No Category",
                            "No Desc",
                            0);
                }
                //Create Instance of DB
                DBInventory Inventory = new DBInventory(CreateItem.this);

                boolean eureka = Inventory.insertOne(ProductItem);


                Toast.makeText(CreateItem.this, "Success=" + eureka, Toast.LENGTH_SHORT).show();

                if (eureka) {
                    Intent intent = new Intent(this, Inventory.class);
                    startActivity(intent);
                }


            });
    }





}