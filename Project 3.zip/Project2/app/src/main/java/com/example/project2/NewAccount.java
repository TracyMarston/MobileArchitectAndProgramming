package com.example.project2;


import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;

import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;



public class NewAccount extends AppCompatActivity {



    EditText createEmail , password, repassword;
    Button signup, btnBack;
    DBLogin DB;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_new_account);

        createEmail = findViewById(R.id.cr_inputEmail);
        password = findViewById(R.id.cr_inputPassword);
        repassword = findViewById(R.id.cr_reInputPassword);
        signup = findViewById(R.id.cr_btnSubmit);
        btnBack = findViewById(R.id.btnBack);


        DB = new DBLogin(this);

        signup.setOnClickListener(view -> {
            String email = createEmail.getText().toString();
            String pass = password.getText().toString();
            String repass = repassword.getText().toString();

            if(email.equals("")||pass.equals("")||repass.equals(""))
             Toast.makeText(NewAccount.this, "Please enter all the fields", Toast.LENGTH_LONG).show();

            else{
                if(pass.equals(repass)){
                    Boolean checkEmail = DB.checkEmail(email);
                    if(!checkEmail){
                        boolean insert = DB.insertData(email, pass);
                        if(insert){
                            Toast.makeText(NewAccount.this, "Registered successfully", Toast.LENGTH_SHORT).show();

                        }else{
                            Toast.makeText(NewAccount.this,
                                    "Registration failed",
                                    Toast.LENGTH_SHORT).show();
                        }
                    }
                    else{
                        Toast.makeText(NewAccount.this, "User already exists! please sign in", Toast.LENGTH_SHORT).show();
                        Intent intent = new Intent(getApplicationContext(),NewAccount.class);
                        startActivity(intent);
                    }
                }else{
                    Toast.makeText(NewAccount.this, "Passwords not matching", Toast.LENGTH_SHORT).show();

                }
            } });


        btnBack.setOnClickListener(v ->{
            Intent intent = new Intent(this, MainActivity.class);
            startActivity(intent);

        });

    }


}