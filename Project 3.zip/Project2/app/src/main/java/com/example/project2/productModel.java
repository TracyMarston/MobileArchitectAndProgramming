package com.example.project2;

import androidx.annotation.NonNull;

public class productModel {

    private Integer ID;
    private String Product;
    private String Category;
    private String Description;
    private Integer Quantity;


    //Constructors
    public productModel(int i, String product, String category, String description, Integer quantity) {
        this.ID = i;
        this.Product = product;
        this.Category = category;
        this.Description = description;
        this.Quantity = quantity;

    }






    //toString Method


    @NonNull
    @Override
    public String toString() {
        return "productModel{" +
                "Product='" + Product + '\'' +
                ", Category='" + Category + '\'' +
                ", Description='" + Description + '\'' +
                ", Quantity=" + Quantity +
                '}';
    }
    public String getProduct() {
        return Product;
    }
    public void setProduct(String product) {
        Product = product;
    }

    public String getCategory() {
        return Category;
    }

    public void setCategory(String category) {
        Category = category;
    }

    public String getDescription() {
        return Description;
    }

    public void setDescription(String description) {
        Description = description;
    }

    public Integer getQuantity() {
        return Quantity;
    }

    public void setQuantity(Integer quantity) {
        Quantity = quantity;
    }


    public Integer getID() {
        return ID;
    }

    public void setID(Integer ID) {
        this.ID = ID;
    }
}
